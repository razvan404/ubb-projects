def global_menu():
    print('  1. Adaugare cuvant intr-o limba si traducerea acestuia in alta limba.')
    print('  2. Vizualizare traduceri pentru o limba data.')
    print('  3. Traduce text dat.')
    print('  0. Opreste aplicatia.')
    return 'Alege o optiune: '

def error():
    print('Optiune invalida, incearca din nou')